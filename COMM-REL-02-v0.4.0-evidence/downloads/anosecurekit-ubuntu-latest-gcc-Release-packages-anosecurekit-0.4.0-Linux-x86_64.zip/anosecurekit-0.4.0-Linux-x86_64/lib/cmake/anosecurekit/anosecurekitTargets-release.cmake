#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "anosecurekit::anosecurekit" for configuration "Release"
set_property(TARGET anosecurekit::anosecurekit APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(anosecurekit::anosecurekit PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libanosecurekit.a"
  )

list(APPEND _cmake_import_check_targets anosecurekit::anosecurekit )
list(APPEND _cmake_import_check_files_for_anosecurekit::anosecurekit "${_IMPORT_PREFIX}/lib/libanosecurekit.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
