// SPDX-License-Identifier: MPL-2.0
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <sstream>
#include <string>
#include <string_view>

#include "anosecurekit/anosecurekit.hpp"

namespace
{

constexpr std::size_t kPacketPrefixSize = 17;
constexpr std::size_t kPacketTagSize = 16;

anosecurekit::bytes ascii_bytes(std::string_view text)
{
	anosecurekit::bytes result;
	result.reserve(text.size());
	for (const char ch : text)
	{
		result.push_back(static_cast<std::byte>(ch));
	}
	return result;
}

void write_file(const std::filesystem::path &path, const anosecurekit::bytes &bytes)
{
	std::ofstream out(path, std::ios::binary | std::ios::trunc);
	out.write(reinterpret_cast<const char *>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
}

anosecurekit::bytes read_file(const std::filesystem::path &path)
{
	std::ifstream in(path, std::ios::binary);
	const std::string data{std::istreambuf_iterator<char>(in), std::istreambuf_iterator<char>()};
	anosecurekit::bytes result;
	result.reserve(data.size());
	for (const unsigned char ch : data)
	{
		result.push_back(static_cast<std::byte>(ch));
	}
	return result;
}

std::string string_from_bytes(const anosecurekit::bytes &bytes)
{
	std::string result;
	result.reserve(bytes.size());
	for (const std::byte byte : bytes)
	{
		result.push_back(static_cast<char>(std::to_integer<unsigned char>(byte)));
	}
	return result;
}

} // namespace

int main()
{
	const auto plaintext = ascii_bytes("AnoSecureKit consumer sample plaintext");
	const auto aad = ascii_bytes("AnoSecureKit consumer sample aad");
	const auto key = anosecurekit::generate_key();

	const auto from_hex = anosecurekit::hex_decode(anosecurekit::hex_encode(plaintext));
	const auto from_base64 = anosecurekit::base64_decode(anosecurekit::base64_encode(from_hex));
	const auto from_base64url = anosecurekit::base64url_decode(anosecurekit::base64url_encode(from_base64));
	const auto digest = anosecurekit::sha256(ascii_bytes("abc"));
	const auto hmac = anosecurekit::hmac_sha256(ascii_bytes("key"), ascii_bytes("The quick brown fox jumps over the lazy dog"));
	const auto hkdf = anosecurekit::hkdf_sha256(ascii_bytes("ikm"), ascii_bytes("salt"), ascii_bytes("info"), 16);
	const auto random = anosecurekit::random_bytes(8);
	const bool version_api_ok = anosecurekit::version() == ANOSECUREKIT_EXPECTED_VERSION &&
	                            anosecurekit::version_major() == ANOSECUREKIT_EXPECTED_VERSION_MAJOR &&
	                            anosecurekit::version_minor() == ANOSECUREKIT_EXPECTED_VERSION_MINOR &&
	                            anosecurekit::version_patch() == ANOSECUREKIT_EXPECTED_VERSION_PATCH;
	bool error_api_ok = false;
	try
	{
		(void)anosecurekit::random_token(0);
	}
	catch (const anosecurekit::error &ex)
	{
		error_api_ok = ex.code() == anosecurekit::error_code::invalid_input &&
		               !std::string_view(ex.what()).empty();
	}

	const auto packet = anosecurekit::encrypt(plaintext, key, aad);
	const auto roundtrip = anosecurekit::decrypt(packet, key, aad);
	anosecurekit::packet_encryptor packet_encryptor(key, aad);
	auto streaming_packet = packet_encryptor.begin();
	const auto stream_part1 = packet_encryptor.update(std::span<const std::byte>(plaintext).first(10));
	const auto stream_part2 = packet_encryptor.update(std::span<const std::byte>(plaintext).subspan(10));
	const auto stream_tag = packet_encryptor.finalize();
	streaming_packet.insert(streaming_packet.end(), stream_part1.begin(), stream_part1.end());
	streaming_packet.insert(streaming_packet.end(), stream_part2.begin(), stream_part2.end());
	streaming_packet.insert(streaming_packet.end(), stream_tag.begin(), stream_tag.end());
	const auto streaming_roundtrip = anosecurekit::decrypt(streaming_packet, key, aad);

	anosecurekit::packet_decryptor packet_decryptor(key, aad);
	const std::span<const std::byte> packet_span(packet);
	packet_decryptor.begin(packet_span.first(kPacketPrefixSize));
	const auto streaming_plaintext = packet_decryptor.update(packet_span.subspan(kPacketPrefixSize, plaintext.size()));
	const auto streaming_tail = packet_decryptor.finalize(packet_span.last(kPacketTagSize));

	const auto wrapped_key = anosecurekit::wrap_key(key, key, aad);
	const auto unwrapped_key = anosecurekit::unwrap_key(wrapped_key, key, aad);
	const std::string token = anosecurekit::random_token(32);

	const auto plain_path = std::filesystem::temp_directory_path() / "anosecurekit-consumer-plain.bin";
	const auto sealed_path = std::filesystem::temp_directory_path() / "anosecurekit-consumer-sealed.skf";
	const auto opened_path = std::filesystem::temp_directory_path() / "anosecurekit-consumer-opened.bin";
	const auto password_sealed_path = std::filesystem::temp_directory_path() / "anosecurekit-consumer-password-sealed.skp";
	const auto password_opened_path = std::filesystem::temp_directory_path() / "anosecurekit-consumer-password-opened.bin";
	const auto password = ascii_bytes("AnoSecureKit consumer password");
	std::filesystem::remove(plain_path);
	std::filesystem::remove(sealed_path);
	std::filesystem::remove(opened_path);
	std::filesystem::remove(password_sealed_path);
	std::filesystem::remove(password_opened_path);

	write_file(plain_path, plaintext);
	anosecurekit::seal_file(plain_path, sealed_path, key, aad);
	anosecurekit::open_file(sealed_path, opened_path, key, aad);
	const auto opened = read_file(opened_path);
	anosecurekit::seal_file_with_password(plain_path, password_sealed_path, password, aad);
	anosecurekit::open_file_with_password(password_sealed_path, password_opened_path, password, aad);
	const auto password_opened = read_file(password_opened_path);

	std::istringstream stream_plaintext(string_from_bytes(plaintext), std::ios::in | std::ios::binary);
	std::ostringstream stream_sealed(std::ios::out | std::ios::binary);
	anosecurekit::seal_file(stream_plaintext, stream_sealed, key, aad);
	std::istringstream stream_ciphertext(stream_sealed.str(), std::ios::in | std::ios::binary);
	std::ostringstream stream_opened_output(std::ios::out | std::ios::binary);
	anosecurekit::open_file(stream_ciphertext, stream_opened_output, key, aad);
	const auto stream_opened = ascii_bytes(stream_opened_output.str());

	std::istringstream password_stream_plaintext(string_from_bytes(plaintext), std::ios::in | std::ios::binary);
	std::ostringstream password_stream_sealed(std::ios::out | std::ios::binary);
	anosecurekit::seal_file_with_password(password_stream_plaintext, password_stream_sealed, password, aad);
	std::istringstream password_stream_ciphertext(password_stream_sealed.str(), std::ios::in | std::ios::binary);
	std::ostringstream password_stream_opened_output(std::ios::out | std::ios::binary);
	anosecurekit::open_file_with_password(password_stream_ciphertext, password_stream_opened_output, password, aad);
	const auto password_stream_opened = ascii_bytes(password_stream_opened_output.str());

	std::filesystem::remove(plain_path);
	std::filesystem::remove(sealed_path);
	std::filesystem::remove(opened_path);
	std::filesystem::remove(password_sealed_path);
	std::filesystem::remove(password_opened_path);

	const bool utility_api_ok = from_base64url == plaintext &&
	                            anosecurekit::hex_encode(digest) ==
	                                "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad" &&
	                            anosecurekit::hex_encode(hmac) ==
	                                "f7bc83f430538424b13298e6aa6fb143ef4d59a14946175997479dbc2d1a3cd8" &&
	                            hkdf.size() == 16 && random.size() == 8 && error_api_ok &&
	                            anosecurekit::constant_time_equal(digest, digest);

	return version_api_ok && utility_api_ok && roundtrip == plaintext && streaming_roundtrip == plaintext &&
	               streaming_plaintext == plaintext && streaming_tail.empty() && unwrapped_key == key &&
	               opened == plaintext && password_opened == plaintext && stream_opened == plaintext &&
	               password_stream_opened == plaintext && !token.empty()
	           ? 0
	           : 1;
}
